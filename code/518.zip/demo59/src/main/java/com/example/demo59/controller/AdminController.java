package com.example.demo59.controller;

import com.example.demo59.entity.*;
import com.example.demo59.service.AdminService;
import com.example.demo59.utils.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

@Controller
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    private AdminService adminService;

//    @ResponseBody
//    @GetMapping("/selectByPrimaryKey/{admin_id}")
//    public Admin selectByPrimaryKey(@PathVariable Integer admin_id) {
//        return adminService.selectByPrimaryKey(admin_id);
//    }

    //登录成功之后的欢迎界面
    @RequestMapping("/welcomeAdmin")
    public String welcome() {
        return "/lr/welcomeAdmin";
    }

    @RequestMapping("/outAdmin")
    public void outUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
//        request.getSession().removeAttribute("session_admin");
        response.sendRedirect("/admin/logInAdmin");
    }

    @GetMapping("/logInAdmin")
    public String listAdmin() {
        return "lr/loginAdmin";
    }


    @PostMapping("/logInAdmin")
    public String Adminlogin(@Valid LogInform logInform, BindingResult
            result, RedirectAttributes attributes,
                             HttpServletRequest request) {

        if (result.hasErrors()) {
            List<FieldError> errors = result.getFieldErrors();
            for (FieldError error : errors) {
                if (Objects.equals(error.getDefaultMessage(), "Username shouldn't be null")) {
                    attributes.addFlashAttribute("errorMsg_0",
                            errors.get(0).getDefaultMessage());
                } else {
                    attributes.addFlashAttribute("errorMsg_1",
                            errors.get(0).getDefaultMessage());
                }
            }
            return "redirect:/admin/logInAdmin";
        } else {
            Admin admin = new Admin();
            admin.setAdminName(logInform.getUserName());
            admin.setPassword(MD5Util.generatePassword(logInform.getPassword()));
            Admin admin1 = adminService.findExistAdmin(admin);
            if (admin1 != null) {
//                request.getSession().setAttribute("session_admin", admin1);
                return "redirect:/admin/welcomeAdmin";
            }
            attributes.addFlashAttribute("errorMsg",
                    "the username or password is wrong");
            return "redirect:/admin/logInAdmin";
        }

    }
}
