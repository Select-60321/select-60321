package com.example.demo59.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.demo59.entity.*;
import com.example.demo59.service.TokenService;
import com.example.demo59.service.UserService;
import com.example.demo59.utils.MD5Util;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.sql.Date;
import java.util.*;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserService userService;
    @Autowired
    TokenService tokenService;

    //登录成功之后的欢迎界面
    @RequestMapping("/welcomeUser")
    public String welcome() {
        return "/lr/welcomeUser";
    }

    //用户注册界面
    @GetMapping("/register")
    public String registerPage() {
        return "lr/register";
    }

    //用户登录界面
    @GetMapping("/logInUser")
    public String list() {
        return "lr/loginUser";
    }

    //登出操作，导航到/logIn页面去
    @RequestMapping("/outUser")
    public void outUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.removeAttribute("user");
        response.sendRedirect("/user/logInUser");
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String registerUser(@Valid RegisterForm registerForm, BindingResult result, RedirectAttributes attributes) {
        attributes.addFlashAttribute("userName", registerForm.getUserName());
        if (result.hasErrors()) {
            List<FieldError> errors = result.getFieldErrors();
            attributes.addFlashAttribute("errorMsg", errors.get(0).getDefaultMessage());
            return "redirect:/user/register";
        } else {
            if (registerForm.getPassword().equals(registerForm.getConfirmPassword())) {
                if (userService.findUserByUsername(registerForm.getUserName()) != null) {
                    attributes.addFlashAttribute("errorMsg", "this username has been registered");
                    return "redirect:/user/register";
                }
                Users users = new Users();
                users.setUserName(registerForm.getUserName());
                users.setPhoneNumber(registerForm.getPhoneNumber());
                users.setIdCardNum(registerForm.getIdCardNum());
                users.setPassword(MD5Util.generatePassword(registerForm.getPassword()));
                userService.insertUser(users);
                attributes.addFlashAttribute("userName", registerForm.getUserName());
                return "redirect:/user/logInUser";
            } else {
                attributes.addFlashAttribute("errorMsg", "The two passwords are not the same.");
                return "redirect:/user/register";
            }
        }
    }

//    @ApiOperation(value = "登录", notes = "登录")
//    @RequestMapping(value = "/logInUser", method = RequestMethod.GET)
//    public Object login(Users users, HttpServletResponse response) {
//        JSONObject jsonObject = new JSONObject();
//        Users userForBase = new Users();
//        userForBase.setUserId(userService.findUserByUsername(users.getUserName()).getUserId());
//        userForBase.setUserName(userService.findUserByUsername(users.getUserName()).getUserName());
//        userForBase.setPassword(userService.findUserByUsername(users.getUserName()).getPassword());
//        if (!userForBase.getPassword().equals(users.getPassword())) {
//            jsonObject.put("message", "登录失败,密码错误");
//            return jsonObject;
//        } else {
//            String token = tokenService.getToken(userForBase);
//            jsonObject.put("token", token);
//
//            Cookie cookie = new Cookie("token", token);
//            cookie.setPath("/");
//            response.addCookie(cookie);
//            return jsonObject;
//        }
//    }

    @PostMapping("/logInUser")
    public String Userlogin(@Valid LogInform logInform,
                            BindingResult result,
                            RedirectAttributes attributes,
                            HttpServletRequest request) {

        if (result.hasErrors()) {
            List<FieldError> errors = result.getFieldErrors();
            for (FieldError error : errors) {
                if (error.getDefaultMessage().equals("Username shouldn't be null")) {
                    attributes.addFlashAttribute("errorMsg_0",
                            errors.get(0).getDefaultMessage());
                } else {
                    attributes.addFlashAttribute("errorMsg_1",
                            errors.get(0).getDefaultMessage());
                }
            }
            return "redirect:/user/logInUser";
        } else {
            Users login = new Users();
            login.setUserName(logInform.getUserName());
            login.setPassword(MD5Util.generatePassword(logInform.getPassword()));
            Users user = userService.findExistUserByUsrnameAndPasswd(login);
            if (user != null) {
                request.setAttribute("user", user);
                return "redirect:/user/welcomeUser";
            }
            attributes.addFlashAttribute("errorMsg",
                    "the username or password is wrong");
            return "redirect:/user/logInUser";
        }
    }

    @ResponseBody
    @GetMapping("/getUserByUserName/{user_name}")
    public Users getUserName(@PathVariable String user_name) {
        return userService.findUserByUsername(user_name);
    }

    @RequestMapping("/buyStaStaInfo")
    public String buyTicket(Model model, @RequestParam("s1") String station1,
                            @RequestParam("s2") String station2,
                            @RequestParam("d") Date date,
                            @RequestParam("id") Integer id) {
        List<BetweenStationsInfo> list = userService.findTicketsBetweenStations(station1, station2, date);
        int order = userService.purchaseTicketsStaToSta(list.get(id - 1), date, 12);
        model.addAttribute("error_msg", "购买成功");
        model.addAttribute("orderId", order);
        model.addAttribute("userName", "nqsnb");
        return "lr/purchasess";
    }

    @RequestMapping("/getUser")
    public String user(Model model, @RequestParam("userName") String userName) {
        Users a = userService.findUserByUsername(userName);
        List<Users> usersList = new ArrayList<>();
        usersList.add(a);
        model.addAttribute("userNameList", usersList);
        return "lr/userInfo";
    }

    //    @RequestMapping("/getOrder")
//    public String order(HttpServletRequest request, Model model, /*@RequestParam("userName") String userName,*/ @RequestParam("orderId") Integer orderId) {
////        List<OrdersDetails> a = userService.getOrdersByNameAndOrderId(userName, orderId);
//        String userName = (Users) request.getAttribute()
//        List<OrdersDetails> a = userService.getOrdersByNameAndOrderId(userName, orderId);
//        model.addAttribute("orderList", a);
//        return "lr/orderInfo";
//    }

    @RequestMapping("/getOrder")
    public String order(Model model, @RequestParam("userName") String userName, @RequestParam("orderId") Integer orderId) {
        List<OrdersDetails> a = userService.getOrdersByNameAndOrderId(userName, orderId);
//        String userName = null;
//        List<OrdersDetails> a = userService.getOrdersByNameAndOrderId(userName, orderId);
        model.addAttribute("orderList", a);
        return "lr/orderInfo";
    }

    @RequestMapping("/getStaStaInfo")
    public String getStaStaInfo(Model model,
                                @RequestParam("s1") String station1,
                                @RequestParam("s2") String station2,
                                @RequestParam("d") Date date
    ) {
        List<BetweenStationsInfo> list = userService.findTicketsBetweenStations(station1, station2, date);
        model.addAttribute("infoList", list);
        model.addAttribute("date", date);
        return "lr/stastaInfo";
    }

    @RequestMapping("/getCityCityInfo")
    public String getCityCityInfo(Model model,
                                  @RequestParam("c1") String city1,
                                  @RequestParam("c2") String city2,
                                  @RequestParam("d") Date date
    ) {
        List<BetweenCitiesInfo> list = userService.findTicketsBetweenCities(city1, city2, date);
        model.addAttribute("infoList", list);
        model.addAttribute("date", date);
        return "lr/citycityInfo";
    }

    @RequestMapping("/getTrains")
    public String getTrains(Model model, @RequestParam("trainNumber") String trainNumber) {
        List<Train> list = userService.trainDetailsByTrainNumber(trainNumber);
        model.addAttribute("trainNumber", trainNumber);
        model.addAttribute("infoList", list);
        return "lr/trainInfo";
    }
//    @RequestMapping("")

}
