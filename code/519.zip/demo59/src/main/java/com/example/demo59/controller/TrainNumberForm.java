package com.example.demo59.controller;

public class TrainNumberForm {
    private String trainNumber;

    public String getTrainNumber() {
        return trainNumber;
    }

    public void setTrainNumber(String trainNumber) {
        this.trainNumber = trainNumber;
    }
}
