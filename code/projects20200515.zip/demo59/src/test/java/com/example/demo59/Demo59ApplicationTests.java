package com.example.demo59;

import com.example.demo59.entity.Admin;
import com.example.demo59.entity.Journeys;
import com.example.demo59.entity.SearchForOrdersWrapper;
import com.example.demo59.entity.Users;
import com.example.demo59.service.AdminService;
import com.example.demo59.service.UserService;
import org.apache.catalina.User;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest
class Demo59ApplicationTests {

    @Autowired
    AdminService adminService;
    @Autowired
    UserService userService;

    @Test
    void contextLoads() {
    }

    @Test
    public void insert() {
        Users users = new Users();
        users.setUser_name("lishilong");
        users.setPassword("88992233");
        users.setPhone_number("18995566288");
        users.setId_card_num("420102200002134014");
//        adminService.insertUser(users);
        System.err.println("注册成功");
    }

    @Test
    public void findAdmin() {
        Admin admin = new Admin();
        admin.setAdmin_name("admin");
        admin.setPassword("password");
        System.err.println(adminService.selectByDynamicSearching(admin));
        //        System.err.println();
    }

    @Test
    public void getorders() {
        //        Users users = adminService.findUserByUsername("黎诗龙");
        //        System.err.println(userService.getorders(users));
        //        System.err.println(userService.selectByPrimaryKeyor(1));
        //        System.err.println(userService.selectByUserName("黎诗龙"));


    }

    @Test
    public void getTicketQuery() {
        System.err.println(userService.findTicketsBetweenStations("汉口", "深圳北"));
    }

    @Test
    public void getTotalNumberCertainTicket() {
        System.err.println(userService.getTotalNumbrCertainTicket("G77", "高铁二等座"));
    }

    @Test
    public void getTotalBoughtNumberCertainTrainTicket() {
//        System.err.println(
//                userService.getTotalBoughtTicketForCertainTrain(27311, 27312, new Date(120, 4, 14)));
    }

    @Test
    public void getTicketQueryBetweenCities() {
        System.err.println(userService.findTicketsBetweenCities("随州市", "武汉市"));
    }

    @Test
    void updateBasicPrice() {
        Map<String, Double> map = new HashMap<>();
//        map.put("高铁商务座", 1.486); // 1.486
//        map.put("高铁一等座", 0.74); // 0.74
//        map.put("高铁二等座", 0.46); // 0.46
        System.err.println(adminService.updateBasicPrice(map));
    }

    @Test
    void trainDetailsByTrainNumber() {
        System.err.println(userService.trainDetailsByTrainNumber("G77"));
    }

    @Test
    void selectAllSeatType() {
        System.err.println(adminService.selectAllSeatType());
    }

    /**
     * 测试找订单的
     */
    @Test
    void selectAllOrdersByUserNameOrUserNameAndOrderId() {
        SearchForOrdersWrapper searchForOrdersWrapper = new SearchForOrdersWrapper();
        searchForOrdersWrapper.setUserName("黎诗龙");
        searchForOrdersWrapper.setOrderId(1);
        System.err.println(userService.getOrderDetails(searchForOrdersWrapper));
    }

    @Test
    void test5(){
        System.err.println(userService.getCarriageNoFromSeatType("G77",2));
    }
}

