package com.example.demo59.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Data;

/**
 * seat_type
 * @author Lori
 */
@Data
public class SeatType implements Serializable {
    private Integer seat_type_id;

    private String seat_name;

    private Double seat_basic_price;

    private static final long serialVersionUID = 1L;

    public Integer getSeat_type_id() {
        return seat_type_id;
    }

    public void setSeat_type_id(Integer seat_type_id) {
        this.seat_type_id = seat_type_id;
    }

    public String getSeat_name() {
        return seat_name;
    }

    public void setSeat_name(String seat_name) {
        this.seat_name = seat_name;
    }

    public Double getSeat_basic_price() {
        return seat_basic_price;
    }

    public void setSeat_basic_price(Double seat_basic_price) {
        this.seat_basic_price = seat_basic_price;
    }
}