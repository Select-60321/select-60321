package com.example.demo59.service;

import com.example.demo59.entity.Admin;
import com.example.demo59.entity.*;
import com.example.demo59.entity.Orders;
import com.example.demo59.entity.Users;
import com.example.demo59.mapper.AdminsMapper;
import com.example.demo59.mapper.SeatTypeMapper;
import com.example.demo59.mapper.UsersMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;


/**
 * 管理员业务端，注入AdminMapper 和 除了TrainMapper之外的Mapper
 */
@Service
public class AdminService {
    @Autowired
    AdminsMapper adminMapper;
    @Autowired
    SeatTypeMapper seatTypeMapper;
    @Autowired
    UsersMapper usersMapper;

    public int updateByPrimaryKeySelective(Admin record) {
        return adminMapper.updateByPrimaryKeySelective(record);
    }

    public int updateByPrimaryKey(Admin record) {
        return adminMapper.updateByPrimaryKey(record);
    }

    public Users findUserByUsernameAndPassword(String username, String password) {
        return usersMapper.findUserByUsernameAndPassword(username, password);
    }

    public Admin selectByDynamicSearching(Admin admin) {
        return adminMapper.selectByDynamicSearching(admin);
    }

    public Users findUserByUsername(String name) {
        return usersMapper.findUserByUsername(name);
    }

    public Users findUserById(Integer user_id) {
        return usersMapper.findUserById(user_id);
    }

    public int updateBasicPrice(Map<String, Double> seatTypeNameList) {
        return seatTypeMapper.updateBasicPrice(seatTypeNameList);
    }

    public List<SeatType> selectAllSeatType() {
        return seatTypeMapper.selectAllSeatType();
    }


}
