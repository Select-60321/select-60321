package com.example.demo59.mapper;

import com.example.demo59.entity.*;
import com.example.demo59.entity.CarriagesKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CarriagesMapper {
    int insert(Carriages record);

    int insertSelective(Carriages record);

    Carriages selectByPrimaryKey(CarriagesKey key);

    int updateByPrimaryKeySelective(Carriages record);

    int updateByPrimaryKey(Carriages record);
}