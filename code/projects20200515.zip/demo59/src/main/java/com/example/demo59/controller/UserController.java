package com.example.demo59.controller;

import com.example.demo59.entity.Orders;
import com.example.demo59.entity.Users;
import com.example.demo59.service.UserService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.*;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserService userService;

    //登录成功之后的欢迎界面
    @RequestMapping("/welcomeUser")
    public String welcome() {
        return "/lr/welcomeUser";
    }

    //用户注册界面
    @GetMapping("/register")
    public String registerPage() {
        return "lr/register";
    }

    //用户登录界面
    @GetMapping("/logInUser")
    public String list() {
        return "lr/loginUser";
    }

    //登出操作，导航到/logIn页面去
    @RequestMapping("/outUser")
    public void outUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.getSession().removeAttribute("session_user");
        response.sendRedirect("/user/logInUser");
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String registerUser(@Valid RegisterForm registerForm, BindingResult result, RedirectAttributes attributes) {
        attributes.addFlashAttribute("userName", registerForm.getUserName());
        if (result.hasErrors()) {
            List<FieldError> errors = result.getFieldErrors();
            attributes.addFlashAttribute("errorMsg", errors.get(0).getDefaultMessage());
            return "redirect:/user/register";
        } else {
            if (registerForm.getPassword().equals(registerForm.getConfirmPassword())) {
                if (userService.findUserByUsername(registerForm.getUserName()) != null) {
                    attributes.addFlashAttribute("errorMsg", "this username has been registered");
                    return "redirect:/user/register";
                }
                Users users = new Users();
                users.setUser_name(registerForm.getUserName());
                users.setPhone_number(registerForm.getPhoneNumber());
                users.setId_card_num(registerForm.getIdCardNum());
                users.setPassword(registerForm.getPassword());
                userService.insertUser(users);
                attributes.addFlashAttribute("userName", registerForm.getUserName());
                return "redirect:/user/logInUser";
            } else {
                attributes.addFlashAttribute("errorMsg", "The two passwords are not the same.");
                return "redirect:/user/register";
            }
        }
    }

    @PostMapping("/logInUser")
    public String Userlogin(@Valid LogInform logInform,
                            BindingResult result,
                            RedirectAttributes attributes,
                            HttpServletRequest request) {

        if (result.hasErrors()) {
            List<FieldError> errors = result.getFieldErrors();
            for (FieldError error : errors) {
                if (error.getDefaultMessage().equals("Username shouldn't be null")) {
                    attributes.addFlashAttribute("errorMsg_0",
                            errors.get(0).getDefaultMessage());
                } else {
                    attributes.addFlashAttribute("errorMsg_1",
                            errors.get(0).getDefaultMessage());
                }
            }
            return "redirect:/user/logInUser";
        } else {
            Users user = userService.findUserByUsernameAndPassword(logInform.getUserName(), logInform.getPassword());
            if (user != null) {
                request.getSession().setAttribute("session_user", user);
                return "redirect:/user/welcomeUser";
            }
            attributes.addFlashAttribute("errorMsg",
                    "the username or password is wrong");
            return "redirect:/user/logInUser";
        }
    }

//    @ResponseBody
//    @GetMapping("/getordersbyusername/{user_name}")
//    public List<Orders> getOrdersByUserName(@PathVariable String user_name){
//        return userService.selectByUserName(user_name);
//    }

}
