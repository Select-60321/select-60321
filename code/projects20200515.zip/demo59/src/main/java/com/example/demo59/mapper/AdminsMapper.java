package com.example.demo59.mapper;

import com.example.demo59.entity.*;

import java.util.List;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface AdminsMapper {
    public int updateByPrimaryKeySelective(Admin record);

    public int updateByPrimaryKey(Admin record);

    public Admin selectByDynamicSearching(Admin admin);
}