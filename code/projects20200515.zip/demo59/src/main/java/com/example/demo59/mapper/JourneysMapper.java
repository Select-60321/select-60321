package com.example.demo59.mapper;

import com.example.demo59.entity.*;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface JourneysMapper {
    int deleteByPrimaryKey(Integer journey_id);

    int insert(Journeys record);

    int insertSelective(Journeys record);

    List<Journeys> selectByTrainNumber(String a);

    Journeys selectByPrimaryKey(Integer journey_id);

    int updateByPrimaryKeySelective(Journeys record);

    int updateByPrimaryKey(Journeys record);
}