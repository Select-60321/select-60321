package com.example.demo59.entity;

import java.io.Serializable;
import lombok.Data;

/**
 * carriages primary key
 * @author lori
 */
@Data
public class CarriagesKey implements Serializable {
    private String train_number;

    private Integer carriage_index;

    private static final long serialVersionUID = 1L;

    public String getTrain_number() {
        return train_number;
    }

    public void setTrain_number(String train_number) {
        this.train_number = train_number;
    }

    public Integer getCarriage_index() {
        return carriage_index;
    }

    public void setCarriage_index(Integer carriage_index) {
        this.carriage_index = carriage_index;
    }

}