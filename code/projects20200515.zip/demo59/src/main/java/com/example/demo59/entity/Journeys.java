package com.example.demo59.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.sql.Time;
import java.util.List;

import lombok.Data;

import javax.print.attribute.standard.JobHoldUntil;

/**
 * journeys
 * @author lori
 */
@Data
public class Journeys implements Serializable {
    private Integer journey_id;

    private String train_id;

    private Integer station_index;

    private Integer station_id;

    private Time arrive_time;

    private Time depart_time;

    private Integer arrive_day;

    private Integer depart_day;

    private Integer distance;

    private static final long serialVersionUID = 1L;

    public Integer getJourney_id() {
        return journey_id;
    }

    public void setJourney_id(Integer journey_id) {
        this.journey_id = journey_id;
    }

    public String getTrain_id() {
        return train_id;
    }

    public void setTrain_id(String train_id) {
        this.train_id = train_id;
    }

    public Integer getStation_index() {
        return station_index;
    }

    public void setStation_index(Integer station_index) {
        this.station_index = station_index;
    }

    public Integer getStation_id() {
        return station_id;
    }

    public void setStation_id(Integer station_id) {
        this.station_id = station_id;
    }

    public Time getArrive_time() {
        return arrive_time;
    }

    public void setArrive_time(Time arrive_time) {
        this.arrive_time = arrive_time;
    }

    public Time getDepart_time() {
        return depart_time;
    }

    public void setDepart_time(Time depart_time) {
        this.depart_time = depart_time;
    }

    public Integer getArrive_day() {
        return arrive_day;
    }

    public void setArrive_day(Integer arrive_day) {
        this.arrive_day = arrive_day;
    }

    public Integer getDepart_day() {
        return depart_day;
    }

    public void setDepart_day(Integer depart_day) {
        this.depart_day = depart_day;
    }

    public Integer getDistance() {
        return distance;
    }

    public void setDistance(Integer distance) {
        this.distance = distance;
    }
}