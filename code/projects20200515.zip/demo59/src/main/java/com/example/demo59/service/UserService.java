package com.example.demo59.service;

import com.example.demo59.entity.Journeys;
import com.example.demo59.entity.Orders;
import com.example.demo59.entity.Users;
import com.example.demo59.entity.*;
import com.example.demo59.mapper.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.Order;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 用户业务端，只注入UserMapper和 TrainMapper
 * 防止改表
 */
@Service
public class UserService {

    @Autowired
    UsersMapper usersMapper;


    public int insert(Users record) {
        return usersMapper.insert(record);
    }

    public Users selectByPrimaryKey(Integer user_id) {
        return usersMapper.selectByPrimaryKey(user_id);
    }


    public Users findUserByUsernameAndPassword(String username, String password) {
        return usersMapper.findUserByUsernameAndPassword(username, password);
    }

    public int insertUser(Users users) {
        return usersMapper.insertUser(users);
    }

    public Users findUserByUsername(String name) {
        return usersMapper.findUserByUsername(name);
    }

    @Autowired
    TrainMapper trainMapper;

    public List<BetweenStationsInfo> findTicketsBetweenStations(String city1, String city2) {
        return trainMapper.findTicketsBetweenStations(city1, city2);
    }

    public List<BetweenCitiesInfo> findTicketsBetweenCities(String city1, String city2) {
        return trainMapper.findTicketsBetweenCities(city1, city2);
    }

    public int getTotalNumbrCertainTicket(String trainNumber, String seatType) {
        return trainMapper.getNumberOfCertainTrainCertainSeatType(trainNumber, seatType);
    }

    public List<CarriageNoAndSeatNo> getCarriageNoFromSeatType(String trainNumber, Integer seatTypeId) {
        return trainMapper.getCarriageNoFromSeatType(trainNumber, seatTypeId);
    }

    public List<Train> trainDetailsByTrainNumber(String trainNumber) {
        return trainMapper.trainDetailsByTrainNumber(trainNumber);
    }

    public List<OrdersDetails> getOrderDetails(SearchForOrdersWrapper searchForOrdersWrapper) {
        return trainMapper.getOrderDetails(searchForOrdersWrapper);
    }
}
