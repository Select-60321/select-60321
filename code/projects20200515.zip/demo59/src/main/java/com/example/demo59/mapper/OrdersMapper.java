package com.example.demo59.mapper;

import com.example.demo59.entity.Orders;
import com.example.demo59.entity.*;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface OrdersMapper {

    int deleteByPrimaryKey(Integer order_id);

    int insert(Orders record);

    int insertSelective(Orders record);

    int updateByPrimaryKeySelective(Orders record);

    int updateByPrimaryKey(Orders record);
}