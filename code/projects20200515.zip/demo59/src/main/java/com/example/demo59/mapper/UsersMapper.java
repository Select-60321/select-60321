package com.example.demo59.mapper;

import com.example.demo59.entity.Journeys;
import com.example.demo59.entity.Orders;
import com.example.demo59.entity.Users;
import com.example.demo59.entity.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import javax.persistence.criteria.Order;

public interface UsersMapper {
    int insert(Users record);

    Users selectByPrimaryKey(Integer user_id);

    public Users findUserByUsernameAndPassword(String username, String password);

    public Users findUserByUsername(String user_name);

    public int insertUser(Users users);

    @Select("select * from users where user_id = #{user_id}")
    public Users findUserById(@Param("user_id") Integer user_id);
}