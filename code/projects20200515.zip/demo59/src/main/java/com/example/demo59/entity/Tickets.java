package com.example.demo59.entity;

import java.io.Serializable;
import java.sql.Date;

import lombok.Data;

/**
 * tickets
 *
 * @author lori
 */
@Data
public class Tickets implements Serializable {
    private Integer ticket_id;

    private Integer order_id;

    private Integer carriage_id;

    private Integer depart_journey;

    private Integer arrive_journey;

    private Date depart_date;

    private static final long serialVersionUID = 1L;

    public Integer getTicket_id() {
        return ticket_id;
    }

    public void setTicket_id(Integer ticket_id) {
        this.ticket_id = ticket_id;
    }

    public Integer getOrder_id() {
        return order_id;
    }

    public void setOrder_id(Integer order_id) {
        this.order_id = order_id;
    }

    public Integer getCarriage_id() {
        return carriage_id;
    }

    public void setCarriage_id(Integer carriage_id) {
        this.carriage_id = carriage_id;
    }

    public Integer getDepart_journey() {
        return depart_journey;
    }

    public void setDepart_journey(Integer depart_journey) {
        this.depart_journey = depart_journey;
    }

    public Integer getArrive_journey() {
        return arrive_journey;
    }

    public void setArrive_journey(Integer arrive_journey) {
        this.arrive_journey = arrive_journey;
    }

    public Date getDepart_date() {
        return depart_date;
    }

    public void setDepart_date(Date depart_date) {
        this.depart_date = depart_date;
    }
}