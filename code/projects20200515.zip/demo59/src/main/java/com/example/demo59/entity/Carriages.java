package com.example.demo59.entity;

import java.io.Serializable;
import lombok.Data;

/**
 * carriages
 * @author lori
 */
@Data
public class Carriages extends CarriagesKey implements Serializable {
    private Integer seat_type_id;

    private Integer seat_num;

    private static final long serialVersionUID = 1L;

    public Integer getSeat_type_id() {
        return seat_type_id;
    }

    public void setSeat_type_id(Integer seat_type_id) {
        this.seat_type_id = seat_type_id;
    }

    public Integer getSeat_num() {
        return seat_num;
    }

    public void setSeat_num(Integer seat_num) {
        this.seat_num = seat_num;
    }


}