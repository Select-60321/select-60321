package com.example.demo59.mapper;

import com.example.demo59.entity.Cities;
import com.example.demo59.entity.Stations;
//import com.example.demo59.entity.StationsExample;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface StationsMapper {
    //增加站还没有写
    Integer selectCityByCityName(String cityName);

    int insert(Stations record);

    Stations selectByPrimaryKey(Integer station_id);

    //更新站点的信息，是否active，这里还差一个trigger要更改journeys表里面的信息
    int updateActiveInfo(@Param("stationNameList") Map<String, Integer> stationNameList);

}